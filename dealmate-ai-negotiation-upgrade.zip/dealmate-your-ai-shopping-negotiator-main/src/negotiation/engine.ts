export type NegotiationStatus = "initiated"|"negotiating"|"accepted"|"rejected"|"walked_away";
export type Sender = "buyer_agent"|"seller_agent";
export type MessageType = "offer"|"counter_offer"|"accept"|"reject"|"final_offer";
export interface NegotiationMessage { id:string; negotiationId:string; sender:Sender; type:MessageType; amount?:number; currency:string; reasoning:string; timestamp:string }
export interface BuyerPolicy { maximumBudget:number; targetPrice:number; maxRounds:number }
export interface SellerPolicy { listedPrice:number; minimumPrice:number; preferredPrice:number; maxRounds:number }
export interface NegotiationSession { negotiationId:string; listedPrice:number; buyerBudget:number; currentBuyerOffer:number; currentSellerOffer:number; round:number; maxRounds:number; status:NegotiationStatus; messages:NegotiationMessage[]; savings:number; savingsPercentage:number }
const r=(n:number)=>Math.round(n*100)/100;
const msg=(s:NegotiationSession,sender:Sender,type:MessageType,amount:number|undefined,reasoning:string):NegotiationMessage=>({id:crypto.randomUUID(),negotiationId:s.negotiationId,sender,type,amount,currency:"INR",reasoning,timestamp:new Date().toISOString()});
export function createNegotiation(listedPrice:number,buyer:BuyerPolicy,seller:SellerPolicy):NegotiationSession {
 const opening=r(Math.min(buyer.maximumBudget, Math.max(listedPrice*.7, buyer.targetPrice*.9)));
 return {negotiationId:crypto.randomUUID(),listedPrice,buyerBudget:buyer.maximumBudget,currentBuyerOffer:opening,currentSellerOffer:listedPrice,round:0,maxRounds:Math.min(buyer.maxRounds,seller.maxRounds),status:"initiated",messages:[],savings:0,savingsPercentage:0};
}
export function runNegotiation(listedPrice:number,buyer:BuyerPolicy,seller:SellerPolicy){
 let s=createNegotiation(listedPrice,buyer,seller); s.status="negotiating";
 const push=(sender:Sender,type:MessageType,amount:number|undefined,reasoning:string)=>s.messages.push(msg(s,sender,type,amount,reasoning));
 let buyerOffer=s.currentBuyerOffer, sellerOffer=listedPrice;
 for(let round=1; round<=s.maxRounds; round++){
  s.round=round; push("buyer_agent",round===1?"offer":"counter_offer",buyerOffer,"Buyer agent submitted a validated offer.");
  if(buyerOffer>=seller.minimumPrice){ sellerOffer=buyerOffer; push("seller_agent","accept",sellerOffer,"Seller accepted the offer."); s.status="accepted"; break; }
  const pressure=(sellerOffer-buyerOffer); const concession=Math.max(pressure*(round===s.maxRounds?0.75:0.35), listedPrice*.01);
  sellerOffer=r(Math.max(seller.minimumPrice,sellerOffer-concession)); s.currentSellerOffer=sellerOffer;
  if(sellerOffer<=buyer.maximumBudget && sellerOffer<=Math.max(buyer.targetPrice*1.08,buyer.maximumBudget*.97)) { push("seller_agent","accept",sellerOffer,"Seller accepted an economically valid price."); s.status="accepted"; break; }
  push("seller_agent",round===s.maxRounds?"final_offer":"counter_offer",sellerOffer,"Seller returned a counteroffer without exposing private constraints.");
  if(round===s.maxRounds || sellerOffer>buyer.maximumBudget && sellerOffer<=seller.minimumPrice){ s.status="walked_away"; break; }
  const gap=Math.max(0,sellerOffer-buyerOffer); const step=Math.max(listedPrice*.01,gap*.45);
  const next=r(Math.min(buyer.maximumBudget,buyerOffer+step));
  if(next<=buyerOffer){ s.status="walked_away"; break; }
  buyerOffer=next; s.currentBuyerOffer=buyerOffer;
 }
 if(s.status==="negotiating") s.status="walked_away";
 const final=s.status==="accepted"?sellerOffer:undefined; s.savings=final?r(listedPrice-final):0; s.savingsPercentage=final?r(s.savings/listedPrice*100):0;
 return {...s, finalPrice:final};
}
